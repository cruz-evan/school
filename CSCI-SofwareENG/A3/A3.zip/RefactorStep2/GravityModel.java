
public interface GravityModel {
	
	public double getGravitationalField();

}
